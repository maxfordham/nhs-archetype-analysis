import warnings


warnings.warn(
    "lib2to3 package is deprecated and may not be able to parse Python 3.10+",
    DeprecationWarning,
    stacklevel=2,
)
