
def test_import_pandas():
    import pandas
    from pandas import read_csv, DataFrame
